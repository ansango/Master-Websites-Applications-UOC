-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 24-12-2020 a las 19:09:13
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `laravel`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articles`
--

CREATE TABLE `articles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` bigint(20) UNSIGNED NOT NULL,
  `published` date NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `articles`
--

INSERT INTO `articles` (`id`, `title`, `author`, `published`, `content`, `image`, `category`, `created_at`, `updated_at`) VALUES
(1, 'Ut facere labore et ullam velit.', 2, '1987-08-24', 'Amet est saepe fugiat omnis fugiat enim. Ullam quo pariatur impedit.', 'ut', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(2, 'Quia ab maxime laboriosam.', 10, '1985-05-19', 'Fuga tempora autem labore qui amet labore quia. Debitis sit sapiente sit velit itaque et. Cum et aut corrupti rerum vero eos fuga.', 'rerum', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(3, 'Sed et facilis perferendis.', 10, '2003-01-15', 'Unde velit itaque pariatur. Unde molestias eos laborum sapiente eius illum molestiae. Quis fugiat et hic qui.', 'et', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(4, 'Vitae architecto voluptatibus placeat accusamus.', 1, '2012-06-22', 'Occaecati qui ipsum ut est illum qui amet. Sit nihil omnis rerum repudiandae. Nostrum ut qui quos eveniet enim voluptates harum. Necessitatibus enim corporis repellat animi.', 'ratione', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(5, 'Voluptas quibusdam animi quasi voluptatibus.', 1, '2012-08-03', 'Perspiciatis sit tempore culpa praesentium. Id at rem eligendi autem. Quo placeat quibusdam earum ratione quod aliquid tempora.', 'exercitationem', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(6, 'Deleniti quam minima possimus omnis est quidem sapiente nemo.', 10, '1994-05-22', 'Tenetur molestiae ut repellendus et illum accusantium et. Est accusantium ut eos consequatur consequatur odit distinctio. Et consequatur nemo at rerum nam et. Non beatae quia voluptatem quas in sed.', 'corporis', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(7, 'Ut qui fugit temporibus autem.', 6, '2012-10-02', 'Fuga quis enim necessitatibus reprehenderit earum. Qui harum cumque illum explicabo vel recusandae. Consequatur adipisci molestiae deserunt. Illo delectus exercitationem ut esse in.', 'fuga', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(8, 'Ut ut ab molestias rem nisi magnam.', 4, '1994-12-28', 'Rerum quasi qui ipsum sed. Placeat dolores ea illo eligendi odit est. Minima ut sed consequuntur quia ut error.', 'laborum', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(9, 'Consequatur pariatur omnis et provident.', 5, '1978-09-23', 'Aspernatur fugit aut dicta ratione omnis et. Illum non dolorum sint a. Veritatis illum debitis nobis omnis sequi. Pariatur omnis rerum sint neque.', 'rerum', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(10, 'Aut modi ullam molestiae molestiae suscipit iusto ipsam.', 9, '2012-05-27', 'Quia architecto eos est debitis quos. Corrupti in quae officia sint dolorem a cumque. Possimus et dolor voluptas reprehenderit omnis. Quibusdam fugit explicabo quis non consequatur.', 'nulla', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(11, 'Animi a odio quos blanditiis.', 6, '1981-06-02', 'Eius rerum enim autem nostrum velit quo unde. Illum qui nam quo incidunt et vero. Ut eos qui sunt architecto molestiae quibusdam accusantium. Sit ipsam expedita veniam saepe dolor.', 'maiores', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(12, 'Officiis sit omnis voluptas voluptas aut voluptatem.', 7, '2013-03-27', 'Quo non eius rerum ut illum cum consectetur. Est incidunt velit quia et ut. Esse beatae et pariatur voluptates cum ab. Officia enim atque eaque qui eum dolor velit.', 'ut', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(13, 'Quaerat sunt modi cum voluptatem tempore eaque.', 2, '1989-10-14', 'Voluptatum excepturi corrupti occaecati. Sint qui minus ab ut aliquid. Maxime quasi alias eos qui ut dolores doloribus natus. Animi autem assumenda vero incidunt sunt ut cupiditate.', 'sed', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(14, 'Sit eveniet porro aliquid nisi recusandae quidem dicta.', 8, '1977-05-25', 'Suscipit et nisi sequi nobis sed maxime voluptate aliquid. Ad aliquam voluptas eius dolorum. Est odio qui sint reprehenderit ea dolorem.', 'eius', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(15, 'Molestiae deserunt voluptas sint qui laboriosam sit eius.', 5, '2012-11-27', 'Expedita eos voluptatem dolorum qui illo aperiam. Similique deleniti modi ea velit omnis voluptas.', 'aperiam', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(16, 'Perferendis commodi voluptatem corrupti incidunt.', 6, '1998-03-18', 'Eligendi quis aliquid sed nemo voluptatem voluptatem occaecati. Velit commodi voluptatem illum incidunt nihil asperiores. Cupiditate molestiae quia odit sunt sequi earum.', 'aut', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(17, 'Cumque eos provident cum voluptatem voluptas aut assumenda.', 3, '1988-08-08', 'Architecto voluptas cupiditate quam iusto est facere. Et laborum veniam harum est quibusdam numquam exercitationem. Et fuga eum rem.', 'nobis', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(18, 'Est provident quis repellendus commodi enim.', 10, '2012-08-19', 'Eum sunt eum nemo eos fugiat rem beatae. Doloribus iure ab dolores aut. Fugit laborum esse repudiandae enim. Quisquam repellendus voluptatem non assumenda nam qui.', 'officiis', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(19, 'Cumque nam assumenda animi exercitationem id dolorem.', 6, '2019-11-17', 'Sit sed sint neque nisi dicta et qui. Expedita error qui occaecati non officia commodi. Quo qui id quia ullam et sint iste. Velit vel totam aut quo molestiae at deleniti ut.', 'quibusdam', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(20, 'Itaque eos quam sit quisquam natus ea.', 7, '1988-09-26', 'Beatae nihil et tempore qui eum dolore ipsum. Et aut occaecati possimus laudantium aut corporis.', 'unde', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(21, 'Ab fugiat dolor explicabo voluptatum voluptate dolorem.', 4, '2013-01-09', 'Et consequatur vitae quos commodi minus tenetur et nostrum. Rerum est aut mollitia. Ut voluptatibus sit dolore aliquid fuga. Itaque architecto quia unde aperiam aliquam ut.', 'praesentium', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(22, 'Et tempore molestias corporis quo.', 6, '1974-06-22', 'Velit possimus qui sed corrupti voluptate reprehenderit. Ut non ut qui excepturi id. Enim dicta minus debitis dolor. Voluptas rerum officia doloribus libero. Iusto explicabo et eligendi qui.', 'corrupti', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(23, 'Libero beatae dolorem molestias dignissimos debitis dolores.', 10, '1991-08-26', 'Laudantium quidem eligendi minima beatae. Voluptas doloribus ipsam consequatur inventore odit et. Odit incidunt enim et qui doloremque dolorem sunt. Iusto occaecati id labore itaque quo qui qui.', 'distinctio', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(24, 'Velit velit eius dolores iste.', 10, '1985-02-24', 'Est qui aut quibusdam aliquam totam. Voluptas distinctio est magnam sunt. Recusandae et ut aliquam excepturi. Ex aliquam necessitatibus sit et minima eligendi sed.', 'et', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(25, 'Quod blanditiis labore recusandae quasi culpa deleniti quam et.', 3, '1971-02-17', 'At natus ab ipsa voluptatem omnis molestias facere repudiandae. Id vel quasi cupiditate velit maxime laudantium numquam. Consequatur quidem eum aut et ipsum reiciendis voluptates.', 'ipsum', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(26, 'Qui enim modi asperiores id cum harum.', 1, '2010-08-25', 'Quaerat qui quasi quam minus. Consequatur sed nobis eum ratione. Delectus impedit est quos eaque.', 'et', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(27, 'In amet a sint magnam velit voluptas similique.', 2, '2014-10-18', 'Ab ducimus et vero iusto molestiae enim. Eius dolor veniam corrupti laudantium quisquam dolorem odit. Vitae vitae culpa ut non aut.', 'ad', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(28, 'Nam pariatur incidunt minus qui labore deleniti nam.', 10, '1997-03-09', 'Dolores voluptatem ipsum ut omnis molestiae et magnam. Nemo soluta eveniet qui in veniam sint et. Sed qui saepe excepturi voluptatum quasi eum.', 'animi', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(29, 'Animi est dolores quo nisi.', 10, '1984-03-12', 'Praesentium qui aut voluptatem. Sed magnam ut quisquam laborum vel aliquid. Fugiat iusto dolorem voluptate animi non soluta. Dolorum voluptas expedita ipsa accusamus et saepe dolorum. Corrupti dolores velit delectus et sunt quas assumenda numquam.', 'tempora', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(30, 'Quo modi repellat consequatur sint repudiandae.', 4, '1986-06-08', 'Repellat ullam rerum aut aut sed. Assumenda ea aspernatur ut minima ad. Dolor quasi quidem consequuntur fuga delectus cum et. Quam mollitia id suscipit voluptatem eos cumque doloremque.', 'rerum', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(31, 'Distinctio nihil doloribus fugiat veniam qui ullam beatae.', 10, '2014-03-17', 'Velit quibusdam ratione inventore repellendus perspiciatis corporis voluptas. Porro nesciunt quo quis deleniti. Explicabo illum accusantium necessitatibus fuga. Est et explicabo dolores quo culpa veritatis.', 'dolorum', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(32, 'Nemo quae animi in odit impedit.', 3, '2010-07-26', 'Aut quod repudiandae veniam nam soluta. Architecto omnis voluptatum nesciunt tempore omnis. Vero sit odit odio doloremque officia corporis.', 'cupiditate', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(33, 'Ex quas quibusdam aut.', 5, '2011-10-16', 'Doloremque assumenda voluptatem ut totam eius perferendis voluptas vel. Et facilis recusandae autem. Commodi quas est perspiciatis iure aperiam autem.', 'voluptas', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(34, 'Excepturi non pariatur mollitia soluta deleniti.', 9, '2018-05-03', 'Enim natus accusantium veritatis ut voluptatem asperiores. Quasi autem qui eum nulla et sed. Eius et debitis debitis et non. Eveniet eligendi sit eum quod et pariatur consectetur.', 'rerum', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(35, 'Quam labore nam modi tenetur.', 6, '1980-06-10', 'Voluptatem molestias consequatur eligendi asperiores. Saepe enim nihil expedita et ea. At voluptatem voluptatibus sint sit tempore excepturi aliquam molestiae.', 'voluptatem', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(36, 'Est nulla ut enim corporis.', 7, '1973-03-02', 'Molestiae laudantium facere et et consequatur. Doloribus culpa dolorum similique odio. Beatae suscipit dolor ea mollitia fugit eum quae.', 'corrupti', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(37, 'Animi perferendis eos harum dolorem reprehenderit rem tenetur.', 4, '1975-12-13', 'Delectus omnis eius nisi accusamus alias quam eos. Beatae tempore est molestias veritatis quae voluptatem. Atque ut temporibus officia enim voluptatem. Quibusdam sunt excepturi est sed fuga.', 'tempore', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(38, 'Ducimus rem qui ipsum quas sunt perspiciatis.', 1, '1981-11-08', 'Fugit repellat totam rerum corporis molestiae et. Modi amet blanditiis est aut magni rerum sed. Voluptatem nihil officia nesciunt voluptatem culpa.', 'sunt', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(39, 'Eveniet ut consectetur nam velit enim.', 3, '2018-02-21', 'Mollitia rerum ea velit et. Facere aperiam veniam dolore repellat doloribus aut. Sed est dolorem enim nam odio ea reiciendis. Veritatis consequatur corrupti omnis aut.', 'quis', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(40, 'Hic et ex doloremque molestiae consequatur est.', 5, '2018-03-06', 'Ex nostrum vel quod ut voluptatem officiis. Voluptatem architecto consequatur amet inventore quod recusandae officiis. Fugit vitae odio iste ab est velit praesentium qui. Soluta numquam doloremque sint veritatis.', 'quibusdam', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(41, 'Tenetur aut a in.', 2, '2016-11-15', 'Pariatur ducimus corrupti rerum quod animi molestias quo. Modi enim optio neque iusto reprehenderit voluptatem. Numquam quia modi dicta ullam veniam aut. Distinctio nulla nihil velit rem minus nihil vero voluptates.', 'enim', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(42, 'Fuga est cupiditate ducimus et et cupiditate enim placeat.', 9, '1998-08-10', 'Fugiat in quia quae. Quia minus inventore eligendi praesentium in aut ab. Nesciunt vitae eaque non repellendus vero.', 'voluptatem', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(43, 'Illum recusandae voluptates dicta sed.', 9, '2016-12-27', 'Accusamus tenetur non voluptas laborum dolores minus. Illum possimus suscipit tempora minus accusantium unde temporibus. Voluptatibus beatae ducimus eum dolorem asperiores cupiditate.', 'architecto', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(44, 'Reprehenderit non veniam culpa perspiciatis.', 9, '2015-05-04', 'Error quo id omnis veritatis quo pariatur. Impedit tempora reiciendis laudantium est totam aperiam sit. Illo neque ipsum incidunt in possimus. Eum consequatur ut vitae molestiae non.', 'ex', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(45, 'Voluptatem impedit est quidem.', 10, '1995-06-21', 'Dolor sint perferendis dolorum praesentium aliquam sed cupiditate. Alias ex necessitatibus nemo doloremque. Doloremque optio totam ea odit.', 'enim', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(46, 'Tempore enim rerum quaerat perferendis eius.', 10, '1999-11-10', 'Molestiae itaque qui nobis qui. Ad consequatur officia qui rem. Velit ullam ut voluptatibus quas architecto quibusdam expedita blanditiis.', 'aliquam', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(47, 'Sunt inventore repellendus aut sapiente veritatis sit.', 6, '2006-07-03', 'Similique temporibus beatae ipsum vel dignissimos. Veniam quia exercitationem voluptatem molestias molestiae. Est aperiam omnis reiciendis vel voluptate.', 'quidem', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(48, 'Ratione consequatur quo laborum voluptas nobis aut eum consectetur.', 9, '1974-03-20', 'Quasi quia aspernatur sunt ex qui aut. Maxime sunt qui eligendi recusandae qui doloribus ut. Qui non ad vitae dolores incidunt.', 'molestiae', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(49, 'Nam sunt et officia aut accusamus repellat.', 9, '1983-07-01', 'Molestias necessitatibus ut necessitatibus dolorum. Architecto quae voluptatibus quia omnis sed. Eos voluptate itaque est non voluptatem id consequatur. Quidem quia non sunt nulla delectus soluta.', 'vel', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(50, 'Et rem quod necessitatibus voluptatibus.', 2, '2020-12-03', 'Fuga velit quia hic fuga hic. Voluptas doloremque et quis eligendi laboriosam voluptatem. Asperiores nihil beatae rerum odit sit fuga est incidunt. Provident iste fuga explicabo dicta sint.', 'molestias', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(51, 'Necessitatibus ducimus dicta qui.', 9, '2019-12-09', 'Quis molestias est inventore quod doloremque. Minima voluptatem dolores ducimus aliquam voluptatum voluptatum nesciunt. Et expedita illum nisi eos exercitationem at dignissimos. Esse molestias facere aperiam. Nobis molestiae est non ea maiores veniam repudiandae porro.', 'et', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(52, 'Placeat dolorem eos ab cupiditate ut eum.', 2, '2013-12-28', 'Saepe perspiciatis aperiam qui amet recusandae ipsam. Excepturi cumque necessitatibus reiciendis quidem dolor labore.', 'ea', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(53, 'Magni in quia ut est nostrum.', 2, '1970-12-22', 'Dolor veniam inventore minima delectus. Dicta qui iure et et sint ipsa sunt.', 'omnis', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(54, 'Numquam voluptates quam tempora nobis et molestiae nulla.', 8, '2001-07-24', 'Ab alias animi culpa. Voluptates aut iusto beatae quam ullam reprehenderit maxime eos. Blanditiis et molestiae enim quasi voluptatem praesentium quo.', 'sunt', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(55, 'Et natus deleniti ducimus aut.', 7, '1976-11-26', 'Quia officiis ut a dolor laudantium. Eligendi alias perspiciatis saepe enim quaerat quis dolorum illo. Quidem nam est quia magnam aspernatur et. Officiis est neque rerum distinctio.', 'ipsam', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(56, 'Repellat laboriosam consequatur unde repellendus.', 1, '2018-05-28', 'Aut qui quia ut quidem sed possimus ducimus veritatis. Quis in ut sed molestiae possimus blanditiis. Porro voluptate numquam animi sit voluptatibus dolorem. Sed cupiditate libero similique voluptatem.', 'ullam', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(57, 'Tenetur reiciendis laboriosam et ipsum alias velit labore.', 1, '1977-08-17', 'Et modi sunt reiciendis hic qui expedita aut deleniti. Veniam odit et ut veniam. Repellendus non recusandae quos dolorem. Itaque debitis alias eos ullam quo consequuntur. Ad eum modi officia hic est voluptatem impedit.', 'sapiente', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(58, 'Quos quia voluptatem sit magni et nesciunt ratione.', 1, '1996-10-10', 'Nam a accusamus explicabo non sit assumenda in. Dicta illum eos quasi quis qui et. Earum quod qui corrupti ducimus a voluptates quisquam est.', 'et', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(59, 'Magnam ut occaecati maiores labore aut et magni.', 4, '1981-01-25', 'Voluptates magnam recusandae tempore similique aliquid ex mollitia. Qui accusantium maiores veniam voluptas libero ut perspiciatis. Ut qui qui ut dolorem nisi. Laudantium perferendis occaecati qui voluptas.', 'minus', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(60, 'Labore non dolorem ea ut fuga voluptates ut.', 2, '1977-07-01', 'Quasi officia voluptas dignissimos reiciendis. Omnis incidunt dolor maiores id ut commodi. Sapiente quo error incidunt voluptatem.', 'repudiandae', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(61, 'Velit perferendis et tenetur alias.', 7, '2019-02-05', 'Nihil hic odit voluptatem voluptatem voluptates corrupti consequatur. Harum sit quaerat ad. Ut eum alias illo quam. Id qui corporis iure. Impedit quis et non ducimus voluptatum perferendis saepe.', 'ab', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(62, 'Eligendi odit ut et vel fugit repellat.', 7, '2016-07-02', 'Rerum quia magnam perspiciatis eum ut dolorum voluptates. Inventore vero earum dolorum sint blanditiis ratione consequuntur. Accusamus voluptatem voluptas quis voluptatibus.', 'ducimus', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(63, 'Repellendus illum possimus cupiditate.', 1, '2014-05-15', 'Aut rerum magnam in quia. Omnis eos enim voluptatem aut consequatur voluptas. Neque sed molestiae quaerat a sint.', 'nostrum', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(64, 'Praesentium commodi molestiae aut eaque soluta aut illum.', 10, '1991-12-14', 'Necessitatibus similique ab culpa occaecati voluptatem. Officiis quas nam consequatur sed. Voluptatem totam inventore repellendus sit architecto officia. Vero sequi aut eum est id quaerat perspiciatis dicta.', 'qui', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(65, 'Totam exercitationem quis occaecati et explicabo aut quae.', 7, '1999-02-10', 'Dolorum sed aut sed tempore. Architecto minima sit ut eveniet doloremque sed. Eligendi enim fugit hic labore fugit. Hic consequatur eum ipsa accusamus voluptas.', 'modi', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(66, 'Quia voluptates adipisci exercitationem delectus exercitationem consectetur.', 3, '1976-10-16', 'Fugiat id quo est. Ut voluptatem rerum optio quia saepe cum. Voluptates consequatur eius consequatur eum.', 'autem', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(67, 'Asperiores suscipit eligendi odio iste cupiditate velit temporibus.', 2, '2009-03-23', 'Sint nobis sunt quasi quis ipsum expedita id. Corporis optio necessitatibus est tempora sequi. Qui accusamus earum eligendi illo voluptas recusandae. Ex corporis quod adipisci culpa saepe ut.', 'minima', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(68, 'Ullam optio et nobis nobis sit.', 6, '1973-08-23', 'Aut et molestiae sapiente voluptatem autem placeat cum. Corporis voluptatum rerum corrupti est aut corrupti fugit. Voluptatem laborum quasi sequi blanditiis.', 'reiciendis', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(69, 'Facilis officia culpa voluptates possimus nulla et deleniti.', 2, '2015-10-29', 'Repellendus maxime pariatur nostrum laborum. Enim velit corporis voluptas eius non accusamus. Itaque qui distinctio omnis sed ex minima aperiam ratione. Omnis voluptas dolorem et sed nihil vel voluptatem.', 'a', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(70, 'Tempore esse autem mollitia suscipit adipisci aliquam.', 4, '2009-05-17', 'Quia voluptatibus sed tempora qui. Voluptas molestias praesentium dolores rem animi. Esse sunt dolores dignissimos ut.', 'et', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(71, 'Cumque similique repudiandae sit animi sit dolorem nostrum.', 3, '1986-10-07', 'Impedit ut veritatis et ipsum facere aspernatur provident. Sunt neque qui vero asperiores quod. Dolore sapiente quisquam doloribus quidem doloribus.', 'aut', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(72, 'Dignissimos consectetur quisquam ea.', 4, '2008-03-29', 'Quibusdam nobis rerum eius debitis. Quam rerum enim rerum. Quia ratione laudantium commodi ut facilis labore in quod. Praesentium quia temporibus et aut repellat iste.', 'dolorem', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(73, 'Magnam sint et qui repellendus possimus nemo sit.', 1, '1993-08-08', 'Deleniti pariatur mollitia voluptas veniam. Consequatur earum dolore neque est odio consequatur. Odit corrupti quia enim repudiandae soluta.', 'reprehenderit', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(74, 'Ipsa beatae tenetur consequatur ut natus omnis.', 3, '1978-04-03', 'Et at ipsam quo. Doloremque animi error neque deserunt.', 'sit', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(75, 'Doloribus eius explicabo voluptatem eaque nihil nostrum praesentium explicabo.', 8, '1979-05-18', 'Quidem ipsum hic sit est nihil. Nobis quidem adipisci est consequatur eos. Unde adipisci voluptatibus necessitatibus consequuntur. Aspernatur blanditiis ex veritatis quisquam voluptatem.', 'eius', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(76, 'Assumenda odio aut nihil qui est doloribus fuga.', 8, '1977-05-19', 'Voluptate quia vel magni velit necessitatibus voluptas. Qui quis aliquam sit. Eveniet aut et perspiciatis. Aut consequatur id fuga ratione.', 'tempora', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(77, 'Eum dignissimos eaque incidunt voluptas aliquid.', 4, '2015-03-05', 'Facere sed ut repellat sint. Modi optio nulla quo voluptatem sed accusantium voluptate. Beatae ducimus laudantium est totam nisi maxime non.', 'expedita', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(78, 'Quia ut optio est.', 4, '1974-04-30', 'Harum et qui quia dolore quisquam. Odio animi facere voluptatibus odit. Quo minima accusamus ipsam accusantium qui reprehenderit. Officiis ullam cupiditate fugiat a et quis voluptates. Quas saepe sed quas.', 'dolores', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(79, 'Facilis officia aspernatur rerum illo assumenda.', 3, '1999-12-06', 'Dolor sit error consectetur et ipsa doloribus quae reiciendis. Laboriosam tempora ut fuga reiciendis nihil. Inventore temporibus aut similique amet illum. Voluptate aliquid repellendus ipsa ut animi quia dolorum. Voluptatem quos earum aut officiis.', 'quidem', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(80, 'Nostrum eum totam ut.', 2, '2017-01-13', 'Culpa id assumenda distinctio. Sit numquam id culpa est qui dignissimos. Aut illum debitis nobis voluptatem nihil voluptas molestiae facere.', 'voluptates', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(81, 'Repellendus a quaerat eligendi accusamus maiores quam unde.', 6, '1992-02-10', 'Voluptatem sapiente quas sequi minus ut iusto. Consequatur cum consequatur quia earum iste. Beatae ipsam voluptatem autem. Quia delectus quae officiis quia.', 'ut', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(82, 'Harum autem sit molestiae deleniti est est ipsum.', 7, '1971-05-29', 'Perspiciatis assumenda mollitia ad ex dignissimos nisi dolor. Atque harum ut non nemo quia. Qui autem quam et eaque consequuntur molestias maxime aliquam. Quas dolore fugit deleniti fuga.', 'fuga', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(83, 'Voluptates voluptatum dolorem dicta omnis.', 5, '1974-06-27', 'Totam atque facilis non animi ex. Eum reiciendis alias laudantium numquam maiores sint.', 'blanditiis', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(84, 'Quisquam accusantium in vitae distinctio laudantium.', 10, '2003-09-11', 'Rerum non nihil occaecati nemo corporis explicabo. Rerum sequi temporibus impedit maxime ipsam. Quis dolorum nobis officiis quas consequuntur voluptatem odio. Tempore illum consequatur delectus.', 'sed', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(85, 'Qui exercitationem nesciunt laborum minima.', 3, '1986-08-11', 'Accusantium necessitatibus reprehenderit omnis maxime. Sunt ut blanditiis porro nam porro. Odio eum doloribus sed est assumenda vel.', 'dolorem', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(86, 'Dolores fugiat corporis voluptatem eum aspernatur veritatis.', 9, '1981-09-24', 'Molestias perferendis voluptatibus et non enim. Quibusdam reprehenderit nihil fuga est eveniet sint magni odio. Sequi molestiae aut fugit ut sed vel eius.', 'omnis', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(87, 'Ut dolore tempore distinctio enim rem.', 4, '1972-08-06', 'Quo illo dolorum asperiores nobis modi. Nam repellendus qui esse reiciendis amet autem omnis. Facere ab voluptatem ut ex.', 'perspiciatis', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(88, 'Et quisquam minima atque fugit voluptatem accusamus laborum.', 2, '1993-10-31', 'Aut iusto occaecati quis ab dolores rerum dolor nisi. Eligendi eos et nesciunt pariatur quos. Aut est enim id minima neque. Molestias voluptas maxime fugit deleniti. Cum eveniet aliquid similique aut ex.', 'sit', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(89, 'Soluta pariatur iusto nam.', 9, '2002-12-25', 'Minus accusantium quia eveniet qui eos magnam necessitatibus sunt. Autem inventore ducimus cupiditate quis. Optio quis consequatur ut illo doloremque distinctio dolores. Deleniti et rem occaecati quam aut quo facilis dolorum.', 'dignissimos', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(90, 'Quibusdam qui laborum ad neque.', 7, '2020-10-27', 'Dolorem et eius vel doloremque eveniet exercitationem ducimus. Aut nostrum dignissimos voluptates consequatur. Provident dolorem beatae possimus eum quibusdam laboriosam.', 'voluptates', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(91, 'In assumenda sint nobis.', 5, '2008-11-07', 'Quas neque nostrum et vel ut eveniet dolor praesentium. Odit vel eos at. Dicta nulla velit eos qui ut delectus minus. Reiciendis vel totam ea.', 'aut', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(92, 'Earum nemo recusandae molestiae reiciendis cum optio maxime.', 10, '1972-05-20', 'Qui consequatur harum eum numquam magni cumque. Vel molestiae nihil culpa nam sed aperiam temporibus. Amet error ad aliquam.', 'veniam', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(93, 'Dolorem consequatur qui velit voluptatem ducimus harum nostrum dolores.', 7, '1993-04-04', 'Et et numquam odio earum sed. Cum assumenda esse ex quis ut eligendi. Dolorem dolor ipsa enim tenetur maxime repellendus debitis.', 'ipsum', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(94, 'Maiores distinctio natus at sed adipisci esse.', 5, '1978-06-10', 'Ipsa illum voluptatibus repudiandae omnis sit fugiat perferendis. Non porro ut in rerum. Temporibus error doloribus reprehenderit ratione nesciunt est.', 'aut', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(95, 'Voluptatem vero quaerat eum sint rerum itaque aspernatur maxime.', 8, '2018-12-15', 'Sed architecto facere autem perferendis nemo quia. Asperiores et eveniet et dolorem. Mollitia eos inventore libero reprehenderit.', 'cumque', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(96, 'Voluptas et ducimus rerum non amet sapiente voluptatem.', 1, '2006-05-18', 'Id doloribus quia enim repellendus distinctio. Error molestias dolorem sint architecto repellat.', 'ea', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(97, 'Aut iusto velit nisi quidem et.', 4, '1985-06-17', 'Et non enim eum consequatur delectus eligendi. Doloremque voluptatem occaecati corrupti amet quaerat est. Libero exercitationem voluptas nesciunt voluptas. Voluptatum voluptate amet fugit.', 'corporis', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(98, 'Quis dolorem nemo eum expedita qui animi.', 4, '2009-11-04', 'Accusamus laboriosam accusantium enim dolorum est. Dolores cum ad ad sed maxime. Odit sunt atque harum et. Quisquam et neque nihil autem eos deleniti corporis velit.', 'cumque', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(99, 'Quia veritatis delectus expedita nisi.', 2, '1971-01-05', 'Quia repellendus dolorem delectus dolor. Iure qui est quidem ut tenetur ipsam. Dolor est et iste sequi quibusdam. Magnam quo neque repellat natus laudantium.', 'quaerat', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(100, 'Earum dicta delectus ipsam ipsam cum dolore.', 9, '2016-10-29', 'Voluptas eos minima eos est nulla facere voluptas. Deleniti autem quisquam saepe dolorem quidem.', 'soluta', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(101, 'Illum architecto facere nesciunt ea ut maxime.', 2, '1989-04-15', 'Molestiae vel qui et minus. Et ut deleniti placeat quam modi. Dolor atque maiores rem quas quia nam iste natus. Qui exercitationem eligendi ipsam sed.', 'maxime', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(102, 'Magnam nihil cum minus consequatur consectetur facilis qui.', 2, '2009-06-26', 'Ipsum necessitatibus hic et eligendi aspernatur perspiciatis eum. Et expedita aut eius voluptatum laborum itaque. Dolores vero odio dolorum sed animi totam.', 'magnam', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(103, 'Atque voluptatem repellat consequuntur perferendis velit exercitationem.', 8, '2018-07-15', 'Provident architecto rem quis vero id. Nobis numquam nobis voluptatem. Praesentium est ut expedita blanditiis eius provident. Sequi sed iusto molestias itaque a. Aspernatur natus dolorem dolorem laborum ea et.', 'nisi', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(104, 'Optio mollitia quasi hic eveniet quia.', 1, '1989-10-03', 'Distinctio aut ab hic voluptas vel. Deserunt atque molestiae corrupti laudantium. Voluptatem magni veniam vel qui.', 'omnis', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(105, 'Ut officiis labore adipisci qui.', 10, '1973-08-23', 'Nobis qui dolorum ducimus cum. Magni libero quam iure quasi excepturi veniam. Minus eveniet optio ea sed quas dolores qui.', 'vero', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(106, 'Dolor ut omnis maxime earum accusantium.', 7, '1976-06-02', 'Nobis at laboriosam aut impedit atque nobis voluptatem. Consequatur aut aut aut. Et est asperiores nam in veritatis omnis. Id sit quibusdam neque nobis odit repellat deserunt.', 'molestias', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(107, 'Quia ea sit voluptatibus perspiciatis totam numquam blanditiis.', 1, '1991-12-19', 'Qui dolorum illum iure qui consequatur. Esse cum vitae at labore consequuntur ducimus. Quos officia eos omnis eaque. Excepturi quasi saepe itaque ut quasi ratione.', 'sapiente', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(108, 'Illo libero mollitia exercitationem ipsam eligendi.', 3, '1994-04-12', 'Ea reiciendis commodi modi sint praesentium expedita et. Unde eligendi nesciunt labore sapiente pariatur. Id voluptatem quis repellendus vitae. Sint facilis labore consequatur porro velit adipisci laboriosam.', 'qui', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(109, 'Vitae excepturi sed quo.', 5, '1982-10-07', 'Quasi nihil ipsam iusto voluptatem et. Fugiat voluptas quod nostrum odio dolorem ipsam et. Dolores rem praesentium maiores velit eius ratione pariatur.', 'ea', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(110, 'Quo ducimus animi quasi atque dolore.', 1, '1989-05-28', 'Dicta corrupti rerum fuga in consequuntur eius eaque. Itaque consequatur aut aliquid dignissimos.', 'dignissimos', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(111, 'Maiores ut facere aut impedit ut.', 1, '2015-11-06', 'Minima non aut quasi non. Aut commodi facilis quibusdam aspernatur explicabo. Culpa quibusdam non nam blanditiis modi reiciendis ratione. Dolorem aut et doloribus velit ex eveniet facilis.', 'velit', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(112, 'Earum unde harum ex enim sint quas.', 9, '1998-12-07', 'Corrupti porro nihil qui optio voluptas. Nostrum dolorem atque molestiae repellat dolorem dicta ullam. Nesciunt et ratione dolorem in eius.', 'illum', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(113, 'Et hic nihil non minima cumque et et sunt.', 9, '1981-10-15', 'Incidunt et aspernatur odio quia aut voluptatem. Commodi dolorem et optio voluptatem ad. Saepe recusandae rerum ab sint vel. Debitis omnis et ut eaque.', 'rerum', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(114, 'Sed dicta inventore deleniti expedita aut voluptatem est.', 1, '1996-09-19', 'Illum tenetur debitis maiores. Non beatae repudiandae consequuntur temporibus eum. Temporibus tempore accusamus impedit eum quibusdam quod. Molestias molestiae rerum optio quia neque. Esse repellendus necessitatibus libero et enim consectetur est.', 'autem', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(115, 'Quibusdam odit quis dolor id non quia aut.', 6, '2002-07-02', 'Provident occaecati reprehenderit placeat quas temporibus inventore et. Quia repellat magni nihil velit. Est nemo ducimus amet animi. Vero cum architecto quis sed quo eos.', 'soluta', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(116, 'Voluptas velit atque occaecati.', 3, '1976-06-14', 'Voluptas consequuntur iure excepturi dolorem est. Amet quaerat numquam animi aperiam hic ut. Quis tempora eligendi temporibus.', 'veritatis', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(117, 'Quisquam et enim tempore est.', 3, '1982-12-24', 'Excepturi eveniet esse molestiae laboriosam. Mollitia voluptate cumque odio et. Id quidem fugit veniam amet. Ea ipsum dolorem error voluptatem aut.', 'voluptates', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(118, 'Impedit at quis atque dolore.', 7, '1991-07-28', 'Perferendis doloremque nemo eaque quia eum sed labore. Est id iste quis aut corrupti odio dolor. Explicabo rerum iste iusto omnis aut perspiciatis.', 'repudiandae', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(119, 'Consequuntur quia deleniti in sed recusandae esse repellendus.', 1, '1981-07-31', 'Nostrum maxime rerum voluptates autem illo pariatur rem odio. Reiciendis molestiae nisi commodi reiciendis repellat. Aut rerum incidunt maiores enim recusandae exercitationem.', 'nisi', 1, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(120, 'Magnam natus ipsum ut placeat sapiente est quod.', 1, '1992-09-25', 'Hic aliquid dolorem natus vel voluptatem nam ut. Dicta minima necessitatibus veritatis. Aspernatur aliquam minima cum deserunt libero modi. Quod perspiciatis saepe non omnis dicta blanditiis minima.', 'rerum', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(121, 'Ea impedit aut mollitia quas.', 9, '1972-01-17', 'Debitis voluptatem assumenda aperiam rerum vel impedit perferendis. Beatae veniam error voluptas et quae. Facilis hic deleniti voluptatum molestias non ad fugit in. Ipsam cupiditate perspiciatis sit accusantium recusandae.', 'eaque', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(122, 'Nisi aut vel perspiciatis nemo.', 6, '2006-06-06', 'Et qui qui quisquam tempore omnis aut. Quo iusto ullam earum voluptas ex non alias. Assumenda labore eos perferendis quo maiores mollitia laudantium.', 'deserunt', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(123, 'Neque quibusdam amet dolores autem.', 8, '1982-09-08', 'Vel a amet qui perspiciatis. Minima beatae voluptates doloribus blanditiis eos ipsa nemo quam. Amet cupiditate quia ratione tempora minima.', 'et', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(124, 'Natus placeat non ipsa et.', 8, '2009-04-11', 'Unde qui est porro et consequatur aut. Architecto totam magnam adipisci tenetur ex. Velit corrupti ea fugiat ea. Reprehenderit voluptate ea iure cum laborum ab.', 'labore', 3, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(125, 'Id animi iure veritatis.', 5, '1991-03-29', 'Distinctio aut libero odit et culpa est. Eos earum repudiandae aliquam libero. Non est quidem dolores quas inventore ea quia saepe. Amet dolores rerum inventore quaerat molestiae voluptatibus libero voluptate.', 'soluta', 4, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(126, 'Qui et aliquid non accusamus.', 8, '1999-11-08', 'Qui vel quas in nulla. Magnam soluta et ducimus nulla. Laudantium qui aut recusandae. Maiores ut cupiditate blanditiis.', 'minima', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(127, 'Consequatur esse quasi libero ut architecto.', 6, '2015-04-24', 'Aspernatur et ab at id quis aliquam. Sed veniam pariatur dolor id reprehenderit quisquam similique vel. Et accusantium impedit recusandae cupiditate. Corrupti deserunt nihil asperiores veritatis eligendi et distinctio et.', 'qui', 5, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(128, 'Iusto possimus temporibus aspernatur iure est aut mollitia.', 1, '2001-04-17', 'Qui aut eos in dolor qui. Culpa nisi voluptatem aut atque rerum asperiores. Sed quas iure nulla delectus et. Qui optio beatae voluptatem inventore aliquam placeat enim exercitationem.', 'eveniet', 2, '2020-12-18 00:04:40', '2020-12-18 00:04:40'),
(129, 'Quis necessitatibus voluptas quisquam veritatis odit quo ut.', 7, '1991-05-06', 'Voluptatem magnam quaerat soluta ea error modi. Sapiente consequuntur aut eum temporibus nihil doloribus expedita dolor. Quis debitis necessitatibus aliquam quos repudiandae. Vitae iste sed voluptates ut eum.', 'exercitationem', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(130, 'Quia aut qui quae quisquam.', 8, '2013-03-21', 'Pariatur a sapiente optio ut velit cum enim quae. Nemo quo rerum sapiente fugit et. Incidunt totam fugit vel cupiditate veniam distinctio cum. Unde consectetur veniam vel sit deleniti dolorum et.', 'voluptas', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(131, 'Error illum qui quis omnis velit rerum.', 5, '2007-11-05', 'Ut sint qui velit et ipsum expedita. Delectus architecto atque id. Soluta quas omnis reprehenderit alias voluptas iusto cupiditate voluptatem.', 'iusto', 5, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(132, 'Veniam nisi assumenda consectetur iure voluptatum.', 1, '1990-11-16', 'Impedit consequatur amet assumenda cupiditate. Impedit voluptatem nihil cupiditate neque temporibus voluptatibus tenetur. Non consequatur aliquam aut sit enim sed dignissimos omnis. Animi quidem aperiam et atque et.', 'ratione', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(133, 'Eligendi dolorum eaque omnis occaecati quos provident.', 5, '2007-01-24', 'Rem repudiandae aut velit esse porro. In fuga maiores sint odio aspernatur blanditiis eligendi. Ea itaque autem consequuntur dolor est.', 'quaerat', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(134, 'Quisquam et quo et consequatur.', 9, '1975-01-29', 'Aliquam odio rerum voluptas rerum quia iste itaque. Provident quis facere architecto rem animi porro. Incidunt sed quia odit architecto deserunt voluptatum.', 'quibusdam', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(135, 'Ducimus nesciunt pariatur ratione tempora.', 3, '2003-03-17', 'Quaerat totam magnam iste quam. Ea aut vero harum est. Aut corporis mollitia impedit voluptate necessitatibus.', 'cumque', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(136, 'Voluptatem amet consequatur doloribus hic quia maxime.', 1, '2008-11-02', 'Earum distinctio facilis qui aperiam est expedita. Aut nesciunt reiciendis dolorum blanditiis officiis animi quis. Rerum facilis autem dignissimos expedita eum amet.', 'repudiandae', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(137, 'Eos consectetur sit velit accusamus porro quae sit repellendus.', 4, '1974-04-05', 'Nam non autem culpa voluptas. Laudantium et voluptatem aspernatur velit laborum fugit. Sed distinctio facere dolores quibusdam.', 'dolores', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(138, 'Et dolorem illum quisquam modi.', 3, '1981-11-16', 'Explicabo aliquid molestiae similique quis quo. Doloribus odit ipsum quia et vitae. Odit non quisquam accusantium et. Itaque possimus et reprehenderit officiis commodi vel corporis. Reiciendis corporis ducimus optio architecto.', 'est', 5, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(139, 'Rerum facere aliquam non.', 3, '2000-04-14', 'Dolorem tempore praesentium quos temporibus et dignissimos ex. Autem perspiciatis velit libero et velit ut debitis.', 'dolorem', 5, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(140, 'Blanditiis minus magnam non ducimus officiis.', 9, '2011-06-15', 'Odio minima consequatur officia tempore sed libero iusto. Quisquam temporibus beatae illum autem excepturi. Neque minima ut eos nihil mollitia nihil.', 'occaecati', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(141, 'Odit et soluta ut maxime voluptas.', 2, '2020-08-15', 'Ipsam voluptatem repellendus voluptatibus aut id. Quia quia maxime ut maxime et dignissimos totam. Vel consequatur eos perspiciatis ut nemo officiis.', 'harum', 5, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(142, 'Dolor qui minus commodi.', 6, '1991-12-01', 'Repudiandae provident iusto reiciendis eos vitae dolorem. Eos enim nulla et officiis blanditiis consequatur et. Voluptatem accusantium mollitia ut.', 'totam', 5, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(143, 'Qui accusamus aut qui fugit ea officia.', 1, '1973-04-28', 'At cum vitae soluta unde labore dolorem beatae repellendus. Facilis ipsam mollitia ex nesciunt. Beatae animi consequatur sit totam beatae blanditiis.', 'voluptates', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(144, 'Aut aut qui a delectus.', 7, '1971-06-30', 'Id et quisquam ipsam et. Illo cum laboriosam et at ea nihil. Commodi et et atque ea ipsa. Sed deserunt odit sed dolore non.', 'non', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(145, 'Ratione impedit alias reiciendis aut nisi qui.', 5, '2017-08-31', 'Repellat tempore facilis sint assumenda error ut tempore. In soluta qui molestias. Neque enim suscipit porro id iure dolore. Incidunt et officiis temporibus rerum.', 'provident', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(146, 'Omnis ea repellendus omnis nesciunt sequi.', 9, '1983-08-07', 'Est quidem quisquam quas voluptatibus tempora doloremque. Similique corrupti animi quaerat. Ea commodi dolor rerum nulla omnis.', 'ut', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(147, 'Necessitatibus pariatur nihil non voluptatem facilis.', 7, '1972-11-20', 'Ad eos omnis eum quia doloribus dolorem. Repellat libero autem quas ducimus vel. Sed temporibus non corporis voluptatem.', 'quos', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(148, 'Beatae molestiae et beatae rerum et magni.', 4, '2006-06-10', 'Qui incidunt iste maxime quos consequuntur. Itaque ex velit et fugit asperiores. Libero odit magni magni illo quo.', 'labore', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(149, 'Quidem quo eligendi et dolor consequuntur illum itaque.', 1, '2000-01-31', 'Ipsa laboriosam sequi vitae eaque amet. Qui vitae quo est enim corrupti odio. Et rem non consequatur ut et voluptas dolor. Neque reiciendis omnis vel sunt facilis nihil.', 'perspiciatis', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(150, 'Quas et nihil incidunt voluptates nemo.', 2, '1996-06-26', 'Et quia non temporibus a quas. Adipisci laudantium exercitationem porro non. Et assumenda et modi nihil. Est tenetur sint saepe quod magnam.', 'totam', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(151, 'Quo assumenda quo ad illum et quasi.', 5, '1998-06-19', 'Vitae modi molestiae sit consectetur blanditiis qui. Qui recusandae quibusdam est ea.', 'occaecati', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(152, 'Laboriosam sunt incidunt reprehenderit dolor.', 4, '2014-01-01', 'Dolore aut asperiores voluptatem et quo velit repellat. Consequuntur quisquam quam sed culpa ipsa eius dignissimos. Harum sapiente fugit est beatae. Adipisci a et necessitatibus unde suscipit dolorem. Possimus ut ullam quibusdam vel.', 'minus', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(153, 'Occaecati assumenda et et animi ab.', 2, '1998-08-10', 'Rerum debitis odio doloremque delectus iusto. Numquam rerum delectus et ratione rerum quasi. Et dicta quia similique accusamus quibusdam. Ullam eius cupiditate maiores aut quis quod numquam.', 'distinctio', 5, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(154, 'Consequatur qui neque quidem temporibus non est ut.', 9, '1988-08-18', 'Maiores tempora reiciendis voluptatem dignissimos. Sed animi doloremque at autem eum rerum. Non dignissimos fuga rerum laudantium tenetur ratione voluptates suscipit.', 'nihil', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(155, 'Qui commodi debitis voluptatum perspiciatis.', 5, '2002-04-28', 'Veniam corporis laboriosam in in totam ex. Autem debitis mollitia sunt. Nam voluptatem eligendi et veniam doloribus.', 'laboriosam', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(156, 'Quia eos cumque cupiditate incidunt quas.', 9, '1971-05-05', 'Ipsa sed voluptatem occaecati perferendis maxime. Saepe sed et debitis magnam quod quas hic. Sunt non totam odio eligendi natus architecto. Rerum dolores qui reiciendis voluptatem nostrum.', 'magnam', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(157, 'Aut aut maxime nihil facilis exercitationem unde natus.', 2, '1984-01-26', 'Esse est aliquid omnis optio tempore. Voluptatem accusamus aut veniam ipsum cupiditate et molestiae. Dolores cupiditate sed et.', 'sed', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(158, 'Voluptatem dolores tenetur eaque nulla.', 4, '2001-10-04', 'Quis modi itaque et rerum minus. Est at culpa nihil necessitatibus assumenda magni tempore. Quibusdam beatae minus exercitationem consequuntur ut tempore.', 'quis', 5, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(159, 'Est vitae quo ipsam amet totam quibusdam nemo.', 6, '1977-11-23', 'Aliquid et consequatur quas quis. Et temporibus blanditiis non cum incidunt. Molestias dolor aut minima.', 'et', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(160, 'Recusandae nemo impedit aut est.', 10, '1982-06-24', 'Occaecati delectus sunt dignissimos nostrum dolorum ipsum commodi. Sapiente ullam non aliquid. Ratione neque ut quaerat dolore vel.', 'ratione', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(161, 'Enim saepe voluptates facere est.', 1, '1997-09-27', 'Corrupti accusamus accusamus consequatur optio nobis. Odio voluptas fuga excepturi consequatur possimus. Error nihil sunt consequatur et omnis labore iste rem.', 'non', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(162, 'Id vel quo voluptatem odit excepturi est.', 8, '2008-11-10', 'Pariatur neque dolore inventore veniam accusantium illo. Veritatis esse corporis totam voluptatem occaecati illum est. Veritatis est libero sed eveniet deserunt consequuntur incidunt.', 'aperiam', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(163, 'Nam voluptatem mollitia qui sequi.', 3, '1974-01-10', 'Possimus est in quod facilis aut. Ad dolorum in aliquam distinctio dolorem laborum. Id perspiciatis est ipsam sunt. Sapiente saepe est et.', 'et', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(164, 'Doloremque ut optio voluptates et similique accusamus vero.', 6, '1993-02-03', 'Quaerat odio dolorum dolores accusamus dicta. Velit aut amet modi. Omnis voluptatem voluptates praesentium quibusdam facere alias ea quis. Quisquam quis rerum deleniti eos numquam.', 'sit', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(165, 'Omnis eaque occaecati aut aperiam.', 7, '2010-02-28', 'Est distinctio est occaecati eius enim tempora quasi. Eligendi et odit atque ea. Veniam id ea asperiores et. Voluptate id libero esse.', 'illum', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(166, 'Quod animi consectetur aut.', 8, '1988-01-11', 'Aperiam nemo harum blanditiis in vel omnis ea beatae. Et ut fuga quo molestiae quis magnam non a. Qui ducimus dicta quia provident rerum.', 'quibusdam', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(167, 'Reiciendis ut aperiam magnam illum expedita voluptatem aut.', 4, '2017-02-06', 'Quisquam aut aperiam explicabo omnis quibusdam. Ut soluta quisquam iure qui et. Aut temporibus exercitationem quibusdam minus vero velit et. Quaerat veniam ipsum nam in nobis recusandae natus.', 'rerum', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(168, 'Non expedita assumenda ad atque.', 10, '1983-04-22', 'Est et et enim consectetur eos rerum. Voluptates officia eaque consectetur libero ut nesciunt animi. Accusantium sunt voluptatibus aut quas.', 'voluptates', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(169, 'Nihil deserunt nulla eos velit omnis.', 10, '1973-05-24', 'Enim non voluptas est. Dolores quo laboriosam natus ut et sapiente porro labore.', 'at', 5, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(170, 'Qui ad quis deleniti.', 6, '2018-03-04', 'Nobis asperiores sed at corrupti quibusdam voluptas. A ut ut nostrum ut. Consequatur harum dignissimos voluptatum minima quia deleniti. Quasi veritatis molestias sint et.', 'asperiores', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(171, 'Doloribus possimus mollitia laudantium ipsa.', 8, '1992-01-08', 'Laborum quia repellat dicta vitae magnam enim voluptate. Dolorem in velit dicta enim magnam est. Sunt ut expedita aut ex.', 'tenetur', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(172, 'Ut ab perferendis vel adipisci harum fugiat.', 6, '2014-11-13', 'Mollitia dolores et odio ut voluptatem officia voluptatem enim. A et aut cumque quia quia dolores. Perspiciatis rerum deleniti rem aspernatur porro repellendus fuga. Rerum pariatur sint et enim atque occaecati.', 'et', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41');
INSERT INTO `articles` (`id`, `title`, `author`, `published`, `content`, `image`, `category`, `created_at`, `updated_at`) VALUES
(173, 'Et officiis error expedita esse ad rerum quis.', 10, '1995-05-15', 'Enim mollitia minima dolorum esse. Distinctio deserunt aliquam magni dolore. A odio ipsam quia neque facere quibusdam. Vel ullam non facilis eum.', 'aut', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(174, 'Sit blanditiis nemo odio provident omnis voluptatem.', 2, '2005-01-28', 'Est voluptates voluptatum vel sint. Esse totam corrupti voluptatem tempora quis eum. Vitae laborum velit et sunt.', 'similique', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(175, 'Beatae eum repellendus adipisci est.', 9, '2005-12-20', 'Non autem magni possimus ipsam architecto sunt. Quos molestiae omnis tempore perferendis sunt. Aut assumenda quos sint eius dolore totam optio.', 'totam', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(176, 'Soluta voluptatum qui consequatur vel.', 9, '2007-11-13', 'Dolore quaerat ut similique qui. Maiores voluptas nulla blanditiis a voluptates sint.', 'quas', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(177, 'Iure rerum cum necessitatibus.', 2, '1983-11-09', 'Quis aliquam non quo est tempora omnis nesciunt. Consectetur qui amet et aut. Asperiores minus voluptatibus doloremque harum ipsam. Facilis error tenetur nostrum ratione aliquam nisi voluptatem sed.', 'itaque', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(178, 'Nemo omnis et debitis et quo.', 5, '2018-10-12', 'Iure et ut voluptatem reprehenderit ut eos quis. Modi cupiditate est eveniet fuga. Molestiae dolores ea et.', 'dolor', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(179, 'Enim dolor omnis et reprehenderit.', 2, '1973-12-20', 'Laudantium error enim voluptas dolor et consequuntur. Nihil placeat eos aut dolores delectus ut. Ipsa commodi maiores ratione ipsam animi omnis voluptatem earum.', 'id', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(180, 'Veritatis molestias sapiente voluptatem omnis dignissimos aut dicta.', 1, '2010-08-06', 'Ullam repellat est est deserunt doloribus. Quaerat pariatur nihil in modi maxime mollitia. Perferendis tempore voluptas error saepe.', 'odit', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(181, 'Et labore et distinctio sed soluta.', 8, '1975-01-28', 'Id earum nisi commodi perspiciatis delectus cum eos. Delectus odio delectus nobis. Sint consequatur impedit vel.', 'vitae', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(182, 'Architecto asperiores magni qui quibusdam qui optio sint voluptatem.', 10, '2007-06-23', 'Aspernatur et laboriosam eum. Laudantium sequi eos in voluptatum asperiores est quod. Ut quia ab sed in omnis deleniti.', 'magni', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(183, 'Dignissimos recusandae hic earum consequatur ut.', 2, '1980-02-07', 'Est officiis ab distinctio corporis. Cupiditate magni harum fugit autem et est sunt.', 'sint', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(184, 'Voluptate incidunt amet vitae beatae.', 4, '2012-02-17', 'Voluptatibus esse maiores repudiandae delectus aut et animi omnis. Consequatur corporis tempore fugit architecto ullam voluptatem aut. Dolores magnam velit quae quos. Dolorem eum totam eos pariatur.', 'voluptas', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(185, 'Voluptatem veniam ipsum facilis mollitia facilis odit error.', 3, '1975-02-04', 'Est enim quod harum sit a consequuntur aut. Suscipit esse cumque omnis qui molestias odio.', 'nihil', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(186, 'Non a animi non iusto.', 6, '1983-03-01', 'Commodi cum et eos provident quae porro. Aut sit consequatur labore distinctio occaecati. Hic non nam beatae quia ducimus consequuntur. Incidunt quibusdam ex est deleniti dolorem dolorum. Laborum libero inventore velit.', 'pariatur', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(187, 'Doloremque omnis architecto minus libero porro.', 4, '2013-08-26', 'Tenetur quos placeat illum. Quia qui perspiciatis doloremque quia dolores voluptas cupiditate deleniti. Perspiciatis sit reiciendis qui eligendi. Qui recusandae minima velit. A soluta velit modi.', 'cupiditate', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(188, 'Sequi cum similique quaerat architecto exercitationem vel commodi.', 7, '1994-06-07', 'Amet quia neque sunt aut non necessitatibus qui praesentium. Quia ratione possimus ut id neque exercitationem. Sit quo vel eius laudantium quia.', 'aut', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(189, 'Placeat dolorem occaecati fugit molestiae repellendus placeat dolores.', 7, '2008-12-28', 'Et ut deleniti animi accusantium qui est neque. Iure atque at rem atque qui voluptates. Est veritatis voluptate repellendus numquam.', 'sit', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(190, 'Soluta ducimus vel id tempora veritatis quia similique.', 8, '2003-05-01', 'Est sit dolor numquam magni minima. Minima quia quis voluptatem magni a incidunt qui. A quos sunt commodi temporibus dolores.', 'omnis', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(191, 'Ea dolor mollitia voluptas quae deserunt est veniam.', 10, '1996-09-24', 'Soluta ab omnis occaecati. Neque sunt ducimus quod itaque necessitatibus. Esse qui doloribus voluptatem non nihil voluptatem. Qui ipsa rerum rem. Omnis fugiat dolorem et.', 'beatae', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(192, 'Quo id cumque recusandae et alias ducimus.', 6, '1996-04-24', 'Ut labore pariatur expedita aperiam explicabo quas culpa. Iure et laboriosam magnam modi ea ea vero. Ullam amet similique corrupti et sit. Quia voluptatem necessitatibus doloribus reiciendis et quis.', 'totam', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(193, 'Rerum voluptatem sequi sunt harum recusandae aliquid et sit.', 1, '2014-03-06', 'Sequi dolores qui accusantium rem. Reiciendis eos vel quo recusandae id occaecati. Iusto saepe cupiditate libero ut. Voluptas commodi suscipit ullam.', 'id', 5, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(194, 'Hic sit facere error maiores.', 2, '2018-11-18', 'Natus eligendi id sint dicta temporibus tempora. Iusto et at quasi aspernatur sed consequuntur exercitationem. Non sed officiis et aut est laborum. Sit et accusamus officiis dolor ea ut dolores.', 'et', 1, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(195, 'Saepe adipisci quo unde voluptatem quae.', 8, '2017-04-20', 'Autem voluptatibus sint accusantium deleniti. Sit eos sed sed perferendis aspernatur. Dolore laboriosam ipsum ut quaerat.', 'et', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(196, 'Rem temporibus consequatur corrupti.', 5, '1971-10-14', 'Qui quisquam tempora et ullam. Assumenda itaque ipsum cumque ratione autem. Dolor ad deserunt voluptatum.', 'quo', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(197, 'Aut praesentium modi aliquid earum quo enim necessitatibus.', 1, '1990-12-30', 'Autem libero officia recusandae quaerat laudantium. At ab velit culpa.', 'assumenda', 5, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(198, 'Aliquam necessitatibus velit dolorem neque et.', 1, '1981-02-16', 'Est cupiditate sunt assumenda veniam incidunt. Beatae sed culpa voluptatem nihil porro. Ut nihil voluptas voluptatem rem saepe.', 'amet', 3, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(199, 'Saepe dolores qui est facere.', 7, '1975-11-28', 'Odio sequi et ab est vero. Eveniet ullam soluta quis aperiam in. Amet laborum vitae et rerum fugiat eligendi est nostrum. Tempora minima illum itaque nobis aut suscipit rem.', 'itaque', 2, '2020-12-18 00:04:41', '2020-12-18 00:04:41'),
(200, 'Sit occaecati consequatur quod maxime sapiente et tenetur.', 1, '1973-10-08', 'Nemo repellat odit aut mollitia. Accusamus est qui esse dignissimos at exercitationem. Distinctio non voluptatem occaecati laudantium eos debitis. Voluptate nam qui rerum illo.', 'nemo', 4, '2020-12-18 00:04:41', '2020-12-18 00:04:41');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `authors`
--

CREATE TABLE `authors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `authors`
--

INSERT INTO `authors` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Alena Harvey', '2020-12-18 00:04:31', '2020-12-18 00:04:31'),
(2, 'Cooper Cummings', '2020-12-18 00:04:31', '2020-12-18 00:04:31'),
(3, 'Deonte Jenkins', '2020-12-18 00:04:31', '2020-12-18 00:04:31'),
(4, 'Chelsey Quigley', '2020-12-18 00:04:31', '2020-12-18 00:04:31'),
(5, 'Lesley Klein I', '2020-12-18 00:04:31', '2020-12-18 00:04:31'),
(6, 'Beau Zulauf', '2020-12-18 00:04:31', '2020-12-18 00:04:31'),
(7, 'Raphael Volkman', '2020-12-18 00:04:31', '2020-12-18 00:04:31'),
(8, 'Cierra Kuhn III', '2020-12-18 00:04:31', '2020-12-18 00:04:31'),
(9, 'Dr. Hildegard Bartoletti', '2020-12-18 00:04:31', '2020-12-18 00:04:31'),
(10, 'Ms. Rosamond Nolan II', '2020-12-18 00:04:31', '2020-12-18 00:04:31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'National', '2020-12-18 00:04:26', '2020-12-18 00:04:26'),
(2, 'International', '2020-12-18 00:04:26', '2020-12-18 00:04:26'),
(3, 'Sports', '2020-12-18 00:04:26', '2020-12-18 00:04:26'),
(4, 'Finance', '2020-12-18 00:04:26', '2020-12-18 00:04:26'),
(5, 'Society', '2020-12-18 00:04:26', '2020-12-18 00:04:26');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(4, '2020_12_17_222259_create_authors_table', 1),
(5, '2020_12_17_222331_create_categories_table', 1),
(6, '2020_12_17_224234_create_articles_table', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `articles_author_foreign` (`author`),
  ADD KEY `articles_category_foreign` (`category`);

--
-- Indices de la tabla `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `articles`
--
ALTER TABLE `articles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT de la tabla `authors`
--
ALTER TABLE `authors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_author_foreign` FOREIGN KEY (`author`) REFERENCES `authors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `articles_category_foreign` FOREIGN KEY (`category`) REFERENCES `categories` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
