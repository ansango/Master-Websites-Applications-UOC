var numbers = [0, 1, 2, 3];
var greatherThanTwo = numbers.filter(function (number) { return number > 2; });
console.log(greatherThanTwo);
