const numbers = [0, 1, 2, 3];
const greatherThanTwo = numbers.filter((number) => number > 2);

console.log(greatherThanTwo);
