enum Country {
  AR,
  BR,
  DE,
  DK,
  ES,
  FI,
  FR,
  GB,
  HT,
  IL,
  IT,
  JP,
  LTU,
  MX,
  NL,
  TR,
  US,
  YUG,
}

export default Country;
