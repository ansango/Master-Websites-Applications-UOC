enum Position {
  PG,
  SG,
  SF,
  PF,
  C,
}

export default Position;
