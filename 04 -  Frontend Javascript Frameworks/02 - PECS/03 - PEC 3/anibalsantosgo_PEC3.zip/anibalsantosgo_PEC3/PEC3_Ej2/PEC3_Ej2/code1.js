"use strict";
exports.__esModule = true;
var a = "banana";
var b = a + 3;
var c = {
    apple: a,
    banana: b
};
var d = c.apple * 4;
