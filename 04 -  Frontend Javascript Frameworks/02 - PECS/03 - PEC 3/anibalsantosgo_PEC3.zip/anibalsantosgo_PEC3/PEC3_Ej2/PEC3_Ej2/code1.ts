export {};
const a = "banana";
const b = a + 3;
const c = {
  apple: a,
  banana: b,
};
const d = c.apple * 4;
