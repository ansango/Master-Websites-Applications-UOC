var a = 1042;
var b = "apples and oranges";
var c = "pineapples";
var d = [true, true, false];
var e = { type: "ficus" };
var f = [1, false];
var g = [3];
var h = null;
