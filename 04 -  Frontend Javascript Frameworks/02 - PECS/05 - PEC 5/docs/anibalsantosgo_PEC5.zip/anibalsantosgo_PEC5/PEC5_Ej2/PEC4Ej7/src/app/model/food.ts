export default class Food {
  constructor(
    public name: string,
    public kcal: number,
    public vegan: boolean,
    public gluten: boolean
  ) {}
}
