import { Wine } from './wine';

describe('Wine', () => {
  it('should create an instance', () => {
    expect(new Wine()).toBeTruthy();
  });
});
