const app = new UserController(new UserService(), new UserView());
