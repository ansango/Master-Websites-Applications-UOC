import { addons } from "@storybook/addons";
import Theme from "./theme";

addons.setConfig({
  theme: Theme,
});
