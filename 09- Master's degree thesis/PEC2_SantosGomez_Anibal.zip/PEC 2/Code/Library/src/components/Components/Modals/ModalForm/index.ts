import ModalForm from "./ModalForm";
import ModalFormProps from "./ModalFormProps";
export { type ModalFormProps };
export default ModalForm;
