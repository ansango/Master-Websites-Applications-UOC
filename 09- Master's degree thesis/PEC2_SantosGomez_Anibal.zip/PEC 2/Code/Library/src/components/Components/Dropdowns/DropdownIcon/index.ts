import DropdownIcon from "./DropdownIcon";
import DropdownIconProps from "./DropdownIconProps";
export { type DropdownIconProps };
export default DropdownIcon;
