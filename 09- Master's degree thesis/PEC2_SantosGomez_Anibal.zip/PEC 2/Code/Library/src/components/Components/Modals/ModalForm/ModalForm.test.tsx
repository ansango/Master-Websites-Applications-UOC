/**
 * ?ModalForm Test
 */

import { render } from "@testing-library/react";

// import ModalForm from "./ModalForm";

describe("<ModalForm />", () => {
  it("should render", () => {
    render(<div />);
    // expect(screen.getByText("ModalForm")).toBeInTheDocument();
  });
});
