import CardImage from "./CardImage";
import CardImageProps from "./CardImageProps";
export { type CardImageProps };
export default CardImage;
