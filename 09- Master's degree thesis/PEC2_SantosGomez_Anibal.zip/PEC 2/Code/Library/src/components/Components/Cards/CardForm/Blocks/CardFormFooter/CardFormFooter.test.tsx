/**
 * ?CardFormFooter Test
 */

import { render } from "@testing-library/react";

// import CardFormFooter, { CardFormFooterProps } from ".";

// const props: CardFormFooterProps = {};

describe("<CardFormFooter />", () => {
  it("should render", () => {
    // render(<CardFormFooter {...props} />);
    render(<div></div>);
    // expect(screen.getByText("CardFormFooter")).toBeInTheDocument();
  });
});
