import Modal from "./Modal";
import ModalProps from "./ModalProps";
export { type ModalProps };
export default Modal;
