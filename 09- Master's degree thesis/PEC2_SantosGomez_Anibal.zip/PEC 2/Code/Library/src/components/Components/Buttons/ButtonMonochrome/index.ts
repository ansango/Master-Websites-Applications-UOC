import ButtonMonochrome from "./ButtonMonochrome";
import ButtonMonochromeProps from "./ButtonMonochromeProps";
export { type ButtonMonochromeProps };
export default ButtonMonochrome;
