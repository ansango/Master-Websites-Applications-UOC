import Modal from "./Modal/Modal";
import ModalPopup from "./ModalPopup/ModalPopup";
import ModalForm from "./ModalForm/ModalForm";
import ModalFeature from "./ModalFeature/ModalFeature";
export { Modal, ModalPopup, ModalForm, ModalFeature };
