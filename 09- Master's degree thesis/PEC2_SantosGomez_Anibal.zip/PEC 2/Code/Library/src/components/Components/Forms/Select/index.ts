import Select from "./Select";
import SelectProps from "./SelectProps";
export { type SelectProps };
export default Select;
