import { ReactElement } from "react";

type ModalProps = {
  opened: boolean;
  element: ReactElement;
};

export default ModalProps;