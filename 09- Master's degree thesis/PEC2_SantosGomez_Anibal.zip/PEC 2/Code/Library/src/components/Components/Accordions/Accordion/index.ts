import Accordion from "./Accordion";
import AccordionProps from "./AccordionProps";
export { type AccordionProps };
export default Accordion;
