import CardEcommerce from "./CardEcommerce";
import CardEcommerceProps from "./CardEcommerceProps";
export { type CardEcommerceProps };
export default CardEcommerce;
