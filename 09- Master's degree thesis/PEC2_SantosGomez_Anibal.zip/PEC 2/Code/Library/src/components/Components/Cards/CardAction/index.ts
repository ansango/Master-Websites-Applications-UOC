import CardAction from "./CardAction";
import CardActionProps from "./CardActionProps";
export { type CardActionProps };
export default CardAction;
