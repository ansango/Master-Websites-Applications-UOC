
type CardFormHeaderProps = {
  title: string;
};

export default CardFormHeaderProps