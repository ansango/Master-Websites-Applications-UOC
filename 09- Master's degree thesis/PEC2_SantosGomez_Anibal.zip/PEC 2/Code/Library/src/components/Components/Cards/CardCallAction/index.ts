import CardCallAction from "./CardCallAction";
import CardCallActionProps from "./CardCallActionProps";
export { type CardCallActionProps };
export default CardCallAction;
