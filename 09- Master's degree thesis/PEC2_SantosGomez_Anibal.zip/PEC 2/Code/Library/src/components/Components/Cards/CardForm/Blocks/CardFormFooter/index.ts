import CardFormFooter from "./CardFormFooter";
import CardFormFooterProps from "./CardFormFooterProps";
export { type CardFormFooterProps };
export default CardFormFooter;