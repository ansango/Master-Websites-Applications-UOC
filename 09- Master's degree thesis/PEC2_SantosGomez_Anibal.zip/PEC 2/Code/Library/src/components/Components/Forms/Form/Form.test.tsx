/**
 * ?Form Test
 */

import { render } from "@testing-library/react";

// import Form from "./Form";

describe("<Form />", () => {
  it("should render", () => {
    render(<div></div>);
    // expect(screen.getByText("Form")).toBeInTheDocument();
  });
});
