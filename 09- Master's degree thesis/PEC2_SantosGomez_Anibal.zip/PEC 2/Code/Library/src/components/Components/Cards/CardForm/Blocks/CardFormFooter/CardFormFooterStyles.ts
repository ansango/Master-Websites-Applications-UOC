/**
 *? CardFormFooter Styles
 */

export const footer = "text-sm font-medium text-gray-500 dark:text-gray-300";
