import { ReactElement } from "react";

type ModalPopupProps = {
  opened: boolean;
  element: ReactElement;
};

export default ModalPopupProps;
