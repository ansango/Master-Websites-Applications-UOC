import Button from "./Button";
import ButtonProps from "./ButtonProps";
export { type ButtonProps };
export default Button;
