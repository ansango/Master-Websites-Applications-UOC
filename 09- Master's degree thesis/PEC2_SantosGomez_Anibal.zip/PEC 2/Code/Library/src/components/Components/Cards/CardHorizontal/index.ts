import CardHorizontal from "./CardHorizontal";
import CardHorizontalProps from "./CardHorizontalProps";
export { type CardHorizontalProps };
export default CardHorizontal;
