import CardInteraction from "./CardInteraction";
import CardInteractionProps from "./CardInteractionProps";
export { type CardInteractionProps };
export default CardInteraction;
