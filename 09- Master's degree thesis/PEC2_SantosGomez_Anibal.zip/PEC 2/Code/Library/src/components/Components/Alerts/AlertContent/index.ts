import AlertContent from "./AlertContent";
import AlertContentProps from "./AlertContentProps";
export { type AlertContentProps };
export default AlertContent;
