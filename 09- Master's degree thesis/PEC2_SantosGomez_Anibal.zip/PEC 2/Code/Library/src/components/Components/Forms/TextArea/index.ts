import TextArea from "./TextArea";
import TextAreaProps from "./TextAreaProps";
export { type TextAreaProps };
export default TextArea;
