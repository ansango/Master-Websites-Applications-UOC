import { ReactNode } from "react";

type CardFormProps = {
  children: ReactNode;
};

export default CardFormProps;
