import Breadcrumb from "./Breadcrumb";
import BreadcrumbProps from "./BreadcrumbProps";
export { type BreadcrumbProps };
export default Breadcrumb;
