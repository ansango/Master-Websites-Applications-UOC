import ButtonDuotone from "./ButtonDuotone";
import ButtonDuotoneProps from "./ButtonDuotoneProps";
export { type ButtonDuotoneProps };
export default ButtonDuotone;
