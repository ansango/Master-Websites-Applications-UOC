import Card from "./Card";
import CardProps from "./CardProps";
export { type CardProps };
export default Card;
