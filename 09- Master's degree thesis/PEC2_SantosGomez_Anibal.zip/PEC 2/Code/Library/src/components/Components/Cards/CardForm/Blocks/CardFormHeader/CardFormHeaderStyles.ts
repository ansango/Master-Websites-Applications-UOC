/**
 *? CardFormHeader Styles
 */

export const title = "text-xl font-medium text-gray-900 dark:text-white";
