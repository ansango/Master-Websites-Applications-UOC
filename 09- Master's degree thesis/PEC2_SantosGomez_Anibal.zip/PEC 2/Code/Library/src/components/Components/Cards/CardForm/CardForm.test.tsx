/**
 * ?CardForm Test
 */

import { render } from "@testing-library/react";

// import CardForm from ".";

describe("<CardForm />", () => {
  it("should render", () => {
    render(<div />);
    // expect(screen.getByText("CardForm")).toBeInTheDocument();
  });
});
