import ButtonIcon from "./ButtonIcon";
import ButtonIconProps from "./ButtonIconProps";
export { type ButtonIconProps };
export default ButtonIcon;
