import CardFeature from "./CardFeature";
import CardFeatureProps from "./CardFeatureProps";
export { type CardFeatureProps };
export default CardFeature;
