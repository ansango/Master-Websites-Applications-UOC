/**
 * ?CardFormHeader Test
 */

import { render } from "@testing-library/react";

// import CardFormHeader, { CardFormHeaderProps } from ".";

// const props: CardFormHeaderProps = {};

describe("<CardFormHeader />", () => {
  it("should render", () => {
    // render(<CardFormHeader {...props} />);
    render(<div></div>);
    // expect(screen.getByText("CardFormHeader")).toBeInTheDocument();
  });
});
