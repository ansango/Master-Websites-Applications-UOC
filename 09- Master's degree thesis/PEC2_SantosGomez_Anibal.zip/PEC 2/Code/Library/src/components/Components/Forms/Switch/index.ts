import Switch from "./Switch";
import SwitchProps from "./SwitchProps";
export { type SwitchProps };
export default Switch;
