import Input from "./Input";
import InputProps from "./InputProps";
export { type InputProps };
export default Input;
