import ModalPopup from "./ModalPopup";
import ModalPopupProps from "./ModalPopupProps";
export { type ModalPopupProps };
export default ModalPopup;
