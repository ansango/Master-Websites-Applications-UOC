import Avatar from "./Avatar";
import AvatarProps from "./AvatarProps";
export { type AvatarProps };
export default Avatar;
