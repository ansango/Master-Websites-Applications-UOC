import ModalFeature from "./ModalFeature";
import ModalFeatureProps from "./ModalFeatureProps";
export { type ModalFeatureProps };
export default ModalFeature;