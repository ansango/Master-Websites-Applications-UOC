/**
 * ?ModalPopup Test
 */

import { render } from "@testing-library/react";

// import ModalPopup from "./ModalPopup";

describe("<ModalPopup />", () => {
  it("should render", () => {
    render(<></>);
    // expect(screen.getByText("ModalPopup")).toBeInTheDocument();
  });
});
