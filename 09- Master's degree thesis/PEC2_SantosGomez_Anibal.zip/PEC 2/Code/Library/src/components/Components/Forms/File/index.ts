import File from "./File";
import FileProps from "./FileProps";
export { type FileProps };
export default File;
