import CardPricing from "./CardPricing";
import CardPricingProps from "./CardPricingProps";
export { type CardPricingProps };
export default CardPricing;
