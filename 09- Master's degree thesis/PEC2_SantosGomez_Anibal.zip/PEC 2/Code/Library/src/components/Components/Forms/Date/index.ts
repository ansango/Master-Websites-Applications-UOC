import Date from "./Date";
import DateProps from "./DateProps";
export { type DateProps };
export default Date;
