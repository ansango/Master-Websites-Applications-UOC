/**
 * ?CardFeature Test
 */

import { render } from "@testing-library/react";

// import CardFeature from ".";

describe("<CardFeature />", () => {
  it("should render", () => {
    render(<div></div>);
    // expect(screen.getByText("CardFeature")).toBeInTheDocument();
  });
});
