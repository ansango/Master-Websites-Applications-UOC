import Image from "./Image";
import ImageProps from "./ImageProps";
export { type ImageProps };
export default Image;
