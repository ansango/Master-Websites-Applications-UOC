import SpinnerGradient from "./SpinnerGradient";
import SpinnerGradientProps from "./SpinnerGradientProps";
export { type SpinnerGradientProps };
export default SpinnerGradient;
