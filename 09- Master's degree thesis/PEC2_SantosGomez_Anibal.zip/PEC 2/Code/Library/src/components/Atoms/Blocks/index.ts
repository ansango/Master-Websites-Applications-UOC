import Title from "./Title";
import Paragraph from "./Paragraph";
import Image from "./Image/";
export { Title, Paragraph, Image };
