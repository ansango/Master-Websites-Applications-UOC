import Badge from "./Badge";
import BadgeProps from "./BadgeProps";
export { type BadgeProps };
export default Badge;
