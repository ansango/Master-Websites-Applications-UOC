import Spinner from "./Spinner";
import SpinnerGradient from "./SpinnerGradient";
export { Spinner, SpinnerGradient };
