import Paragraph from "./Paragraph";
import ParagraphProps from "./ParagraphProps";
export { type ParagraphProps };
export default Paragraph;
