import BadgeCounter from "./BadgeCounter";
import BadgeCounterProps from "./BadgeCounterProps";
export { type BadgeCounterProps };
export default BadgeCounter;
