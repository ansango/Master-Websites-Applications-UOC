import Spinner from "./Spinner";
import SpinnerProps from "./SpinnerProps";
export { type SpinnerProps };
export default Spinner;
