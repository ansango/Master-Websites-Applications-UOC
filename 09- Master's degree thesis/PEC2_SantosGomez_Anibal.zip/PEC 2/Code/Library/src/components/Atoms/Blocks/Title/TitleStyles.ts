/**
 *? Title Styles
 */

/**
 ** Write your tailwind classes as objects and strings and import them in your component
 */

export const title = "mb-2.5 text-2xl font-bold tracking-tight text-gray-900 dark:text-white";
