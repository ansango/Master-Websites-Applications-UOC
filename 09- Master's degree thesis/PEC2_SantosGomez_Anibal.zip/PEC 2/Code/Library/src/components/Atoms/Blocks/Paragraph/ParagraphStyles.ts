/**
 *? Paragraph Styles
 */

export const paragraph = "font-normal text-gray-700 dark:text-gray-400 mb-2.5";
