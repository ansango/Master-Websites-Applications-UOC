import Icon from "./Icon";
import IconProps from "./IconProps";
export { type IconProps };
export default Icon;
