type TitleProps = {
  /**
   * string
   */
  title: string;
};

export default TitleProps;
