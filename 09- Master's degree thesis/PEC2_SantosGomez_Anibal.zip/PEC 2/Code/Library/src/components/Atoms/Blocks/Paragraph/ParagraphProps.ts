type ParagraphProps = {
  /**
   * string
   */
  content: string;
};

export default ParagraphProps;
