import Title from "./Title";
import TitleProps from "./TitleProps";
export { type TitleProps };
export default Title;
