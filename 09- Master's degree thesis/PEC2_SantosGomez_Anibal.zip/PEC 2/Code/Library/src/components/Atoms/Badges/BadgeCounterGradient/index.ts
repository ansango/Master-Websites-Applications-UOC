import BadgeCounterGradient from "./BadgeCounterGradient";
import BadgeCounterGradientProps from "./BadgeCounterGradientProps";
export { type BadgeCounterGradientProps };
export default BadgeCounterGradient;
