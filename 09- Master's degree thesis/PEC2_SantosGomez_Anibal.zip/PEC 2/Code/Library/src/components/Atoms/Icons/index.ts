import Icon from "./Icon/";
import IconSimple from "./IconSimple";
export { Icon, IconSimple };
