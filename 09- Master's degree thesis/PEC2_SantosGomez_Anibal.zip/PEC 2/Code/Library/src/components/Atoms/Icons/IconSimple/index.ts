import IconSimple from "./IconSimple";
import IconSimpleProps from "./IconSimpleProps";
export { type IconSimpleProps };
export default IconSimple;
