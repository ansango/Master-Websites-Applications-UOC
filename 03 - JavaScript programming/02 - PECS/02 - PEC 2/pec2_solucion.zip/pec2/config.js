export const DATA_API_HOST = 'omgvamp-hearthstone-v1.p.rapidapi.com';
export const DATA_API_TOKEN = 'c1d8a64b79mshe833a7d0f290827p12aa82jsn1ca17e11b9aa';

const DATA_API = `https://${DATA_API_HOST}`;
const IMAGES_API = 'https://art.hearthstonejson.com/v1/render/latest/enUS/256x';

export const ENDPOINTS = {
  INFO: `${DATA_API}/info`,
  CLASSES: `${DATA_API}/cards/classes`,
  IMAGES: IMAGES_API
};
