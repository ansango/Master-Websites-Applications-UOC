export class DeckBuilder {
  init(apiData) {
    const { classes, sets, types, factions, qualities, races } = apiData;

    this._info = { classes, sets, types, factions, qualities, races };
    this._cards = {
      all: new Map(),
      byClass: {},
    };
  }

  get info() {
    return this._info;
  }

  get cards() {
    return this._cards;
  }

  getCardsById(id) {
    return this._cards.all.get(id);
  }

  getCardsByClass(cardClass) {
    if (this._cards.byClass.hasOwnProperty(cardClass)) {
      return this._cards.byClass[cardClass];
    }
  }

  setCardsByClass(cardClass, cardsByClass) {
    this._cards.all = new Map([...this._cards.all, ...cardsByClass]);
    this._cards.byClass[cardClass] = cardsByClass.keys();
  }
}

const DeckBuilderSingleton = new DeckBuilder();

export default DeckBuilderSingleton;
