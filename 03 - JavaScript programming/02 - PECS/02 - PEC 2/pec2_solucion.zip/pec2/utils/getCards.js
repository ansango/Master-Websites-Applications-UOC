import DeckBuilderSingleton from '../Classes/DeckBuilder';
import Card from '../Classes/Card';
import { requestCardsByClass } from '../api';

const ACTION_BY_SELECTOR_NAME = {
  classes: getCardsByClass
};

export async function getCardsByClass(cardClass) {
  const localCardsByClass = DeckBuilderSingleton.getCardsByClass(cardClass);

  if (localCardsByClass) {
    return localCardsByClass;
  }

  const apiData = await requestCardsByClass(cardClass);
  const cardsByClass = new Map();

  apiData.forEach(cardData => cardsByClass.set(cardData.cardId, new Card(cardData)));
  DeckBuilderSingleton.setCardsByClass(cardClass, cardsByClass);
}

export async function getCardsBySelector(event) {
  const { name, value } = event.target;
  const getCardsMethod = ACTION_BY_SELECTOR_NAME[name];

  getCardsMethod(value);
}
