import DeckBuilder from "./DeckBuilder";
export default class View {
  constructor() {
    this.deckBuilder = new DeckBuilder();
    this.rootElement = document.getElementById("app");
    this.init();
  }

  async init() {
    await this.deckBuilder.getInfo();
    await this.deckBuilder.getCardById("LOOTA_BOSS_48h");
    await this.deckBuilder.getCardsByClass("Hunter");
    this.createSelectors();
    this.createCardById();
    this.createCardsByClass();
  }

  createSelectors() {
    console.log("All Selectors", this.deckBuilder.filters);
  }

  createCardById() {
    console.log("Cards by Id", this.deckBuilder.card);
  }

  createCardsByClass() {
    console.log("Cards by Class", this.deckBuilder.cardsByClass);
  }
}
