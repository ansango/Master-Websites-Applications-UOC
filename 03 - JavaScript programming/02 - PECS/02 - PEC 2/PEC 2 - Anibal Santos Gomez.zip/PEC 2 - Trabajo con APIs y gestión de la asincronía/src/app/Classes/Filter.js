export default class Filter {
  constructor(data) {
    this.classes = data.classes;
    this.sets = data.sets;
    this.types = data.types;
    this.factions = data.factions;
    this.qualities = data.qualities;
    this.races = data.races;
  }
}
