import { View } from "./Classes/index";
export default async function init() {
  const frontView = new View();
  return frontView;
}
