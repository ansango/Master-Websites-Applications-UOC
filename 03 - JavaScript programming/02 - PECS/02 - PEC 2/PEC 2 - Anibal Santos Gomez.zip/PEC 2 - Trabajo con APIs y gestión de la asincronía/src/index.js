import init from './app/index'

console.log('UOC - Javascript')

init()
